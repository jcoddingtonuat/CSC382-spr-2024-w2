#pragma once


#include <time.h>
#include <iostream>
#include <algorithm>


class Bubble
{
public:
	void bubble(int arr[], int n);
	void printArray(int arr[], int size);
};